<?php
session_start();
include_once 'dbconnect.php';
include "conn.php";
if (isset($_SESSION['usr_id'])) {
  } else { 
    header("Location: login.php");
  }

include_once 'conexion/dbconnect.php';
include_once 'conexion/conexion.php';
include_once 'conexion/configuration.php';
include_once 'objects/class.database.php';
include_once 'objects/class.visita.php';

	$visita = new visita();
	$visita->razonSocial=$_REQUEST['razonSocial'];
	$visita->fecha=$_REQUEST['fecha'];
	$visita->hora=$_REQUEST['hora'];
	$visita->motivo=$_REQUEST['motivo'];
	$visita->accesorio =$_REQUEST['accesorio'];
	$visita->marca =$_REQUEST['marca'];
	$visita->codigoEquipo =$_REQUEST['codigoEquipo'];
	$visita->codigoDesbloqueo =$_REQUEST['codigoDesbloqueo'];
	$visita->falla =$_REQUEST['falla'];
	$visita->estadoEquipo =$_REQUEST['estadoEquipo'];
	$visita->descripción =$_REQUEST['descripción'];
	$visita->recomendación =$_REQUEST['recomendación'];
	$visita->name =$_REQUEST['name'];

	if ($visita->Save()){
		$variableMensaje = 1;
		header("location:informe.php?variableMensaje=".$variableMensaje);
	}else{
		$variableMensaje = 0;
		header("location:informe.php?variableMensaje=".$variableMensaje);
	};
