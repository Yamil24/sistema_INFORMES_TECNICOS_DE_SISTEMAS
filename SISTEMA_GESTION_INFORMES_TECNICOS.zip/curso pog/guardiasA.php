<?php
session_start();
include_once 'dbconnect.php';
include "conn.php";
if (isset($_SESSION['usr_id'])) {
  } else { 
    header("Location: login.php");
  }
  error_reporting(E_ALL & ~(E_WARNING|E_NOTICE));
  ini_set("display_errors", 0);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap-flex.min.css">
    <script src="https://use.fontawesome.com/5765211a64.js"></script>
    <link rel="stylesheet" href="css/app.css">
<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
    <link rel="stylesheet" href="datatables/dataTables.bootstrap.css"/>

        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        
        <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'    rel='stylesheet'>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <title>IT - SUPPORTECH</title>
    
  </head>
  <body style="margin-bottom: 30px;">
    <!-- Header -->

    <header id="header-container">
      <div class="container">
        <div class="row flex-items-xs-middle flex-items-xs-between">
          <div class="col-xs-6">
            <h1 class="pull-xs-left"> | IT - SUPPORTECH | </h1>
          </div>
          <div class="col-xs-6">
            <button class="navbar-toggler pull-xs-right hidden-sm-up" type="button" data-toggle="collapse" data-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
              &#9776;
            </button>
            <button class="btn btn-danger" style="float: right;"><a href="logout.php" class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Salir</a></button>
            <p class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Usuario: <i class="btn btn-success btn-xs"><b><?php echo $_SESSION['usr_name']; ?></b></i></p>
          </div>
        </div>
      </div>
    </header>
    

    <!-- /Header -->

    <!-- Menu -->

    <div id="menu-container">
      <nav id="navMenu" class="navbar-toggleable-xs navbar navbar-light collapse">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-md-12 col-sm-12">
              <ul class="nav navbar-nav">
                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item text-xs-center active">
                  <a class="nav-link" href="guardiasGC.php">Clientes</a>
                </li>

                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="solicitar.php">Solicitar Visita</a>
                </li>

                <li class="nav-item hidden-sm-up text-xs-center">
                  <a class="nav-link" href="#">Salir</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>

    </div>

    <!-- /Menu -->

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
						
						if(@$_GET['variableMensaje']==1){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido registrado correctamente.</div>';
						}if(@$_GET['variableMensaje']==2){
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
						}
						?> 

            <blockquote>
            <h2>Agregar Cliente</h2>
            </blockquote>
                         <form name="form1" id="form1" class="form-horizontal row-fluid" action="guardiasAA.php" method="POST" >
										<div class="control-group">
                      <label class="control-label" for="Ruc">RUC</label>
                      <div class="controls">
                        <input type="text" name="ruc" id="ruc" class="form-control" required>
                      </div>
                    </div>

                    <div class="control-group">
                      <label class="control-label" for="RazonSocial">Razon Social</label>
                      <div class="controls">
                        <input type="text" name="rs" id="rs" class="form-control" required>
                      </div>
                    </div>

                    <div class="control-group">
                      <label class="control-label" for="Direccion">Direccion</label>
                      <div class="controls">
                        <input name="direccion" id="direccion" class="form-control" type="text" required />
                      </div>
                    </div>

                    <div class="control-group">
                      <label class="control-label" for="Telefono">Telefono</label>
                      <div class="controls">
                        <input name="telefono" id="telefono" class="form-control" type="text" required />
                      </div>
                    </div>

										<div class="control-group">
											<label class="control-label" for="Celular">Celular</label>
											<div class="controls">
												<input name="celular" id="celular" class="form-control" type="text" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="email">Correo</label>
											<div class="controls">
												<input type="email" id="correo" name="correo" class="form-control" required>
											</div>
										</div>

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="input" id="input" class="btn btn-sm btn-primary">Registrar</button>
                        						<a href="guardiasGC.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" integrity="sha384-THPy051/pYDQGanwU6poAc/hOdQxjnOEXzbT+OuUAFqNqFjL+4IGLBgCJC3ZOShY" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="js/chosen_v1.4.2/chosen.css" />
  <script src="js/chosen_v1.4.2/chosen.jquery.js"></script>
<script type="text/javascript">
   var config = {
       '.chosen-select'           : {},
        '.chosen-select-deselect'  : {allow_single_deselect:true},
        '.chosen-select-no-single' : {disable_search_threshold:10},
       '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
        '.chosen-select-width'     : {width:"20%"}
     }
       for (var selector in config) {
         $(selector).chosen(config[selector]);
     }
  </script>
          <footer style="
        position: fixed;
    bottom: 0;
    width: 100%;
    height: 30px;
    text-align: right;">
          <div class="container">
            <p>Desarrollado por <a href="http://difficult-meat.surge.sh/" target="_blank">YAMIL FERNANDEZ</a></p>
          </div>  
        </footer>
  </body>
</html>