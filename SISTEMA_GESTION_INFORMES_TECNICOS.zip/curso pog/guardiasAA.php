<?php
session_start();
include_once 'dbconnect.php';
include "conn.php";
if (isset($_SESSION['usr_id'])) {
  } else { 
    header("Location: login.php");
  }

 include_once 'conexion/dbconnect.php';
include_once 'conexion/conexion.php';
include_once 'conexion/configuration.php';
include_once 'objects/class.database.php';
include_once 'objects/class.guardias.php';

	$clientes = new clientes();
	$clientes->ruc=$_REQUEST['ruc'];
	$clientes->rs=$_REQUEST['rs'];
	$clientes->direccion=$_REQUEST['direccion'];
	$clientes->telefono=$_REQUEST['telefono'];
	$clientes->celular=$_REQUEST['celular'];
	$clientes->correo=$_REQUEST['correo'];

	if ($clientes->Save()){
		$variableMensaje = 1;
		header("location:guardiasA.php?variableMensaje=".$variableMensaje);
	}else{
		$variableMensaje = 0;
		header("location:guardiasA.php?variableMensaje=".$variableMensaje);
	};
