<?php
session_start();
include_once 'dbconnect.php';
include "conn.php";
if (isset($_SESSION['usr_id'])) {
  } else { 
    header("Location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap-flex.min.css">
    <script src="https://use.fontawesome.com/5765211a64.js"></script>
    <link rel="stylesheet" href="css/app.css">
<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
    <link rel="stylesheet" href="datatables/dataTables.bootstrap.css"/>
  
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        
        <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'    rel='stylesheet'>

        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<title>IT - SUPPORTECH</title>

  </head>
  <body style="margin-bottom: 30px;">
    <!-- Header -->

    <header id="header-container">
      <div class="container">
        <div class="row flex-items-xs-middle flex-items-xs-between">
          <div class="col-xs-6">
            <h1 class="pull-xs-left"> | IT - SUPPORTECH | </h1>
          </div>
          <div class="col-xs-6">
            <button class="navbar-toggler pull-xs-right hidden-sm-up" type="button" data-toggle="collapse" data-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
              &#9776;
            </button>
            <button class="btn btn-danger" style="float: right;"><a href="logout.php" class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Salir</a></button>
            <p class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Usuario: <i class="btn btn-success btn-xs"><b><?php echo $_SESSION['usr_name']; ?></b></i></p>
          </div>
        </div>
      </div>
    </header>
    

    <!-- /Header -->

    <!-- Menu -->

    <div id="menu-container">
      <nav id="navMenu" class="navbar-toggleable-xs navbar navbar-light collapse">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-md-12 col-sm-12">
              <ul class="nav navbar-nav">
                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
                </li>
               
                <li class="nav-item text-xs-center active">
                  <a class="nav-link" href="guardiasGC.php">Clientes</a>
                </li>

                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="solicitar.php">Solicitar Visita</a>
                </li>

                <li class="nav-item hidden-sm-up text-xs-center">
                  <a class="nav-link" href="#">Salir</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>

    </div>

    <!-- /Menu -->

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
           $id = intval($_GET['id']);
			$sql = mysqli_query($conn, "SELECT * FROM cliente WHERE id = '$id' ");
			if(mysqli_num_rows($sql) == 0){
				header("Location: index.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			?>
            
            <blockquote>
            <h2>Editar Guardia</h2>
            </blockquote>
                  <form name="form1" id="form1" class="form-horizontal row-fluid" action="guardiasMA.php" method="get" >
                    <div class="control-group">
                      <label class="control-label" for="basicinput">NUMERO DE LISTA</label>
                      <div class="controls">
                        <input type="text" name="id" id="id" value="<?php echo $row['id']; ?>" class="form-control" readonly="readonly">
                      </div>
                    </div>
										<div class="control-group">
											<label class="control-label" for="basicinput">RUC</label>
											<div class="controls">
												<input type="text" name="ruc" id="ruc" value="<?php echo $row['ruc']; ?>" class="form-control" readonly="readonly">
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Razon Social</label>
											<div class="controls">
												<input type="text" name="rs" id="rs" value="<?php echo $row['razonSocial']; ?>" placeholder="" class="form-control" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Direccion</label>
											<div class="controls">
												<input type="text" name="direccion" id="direccion" value="<?php echo $row['direccion']; ?>" class="form-control" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Telefono</label>
											<div class="controls">
												<input name="telefono" id="telefono" value="<?php echo $row['telefono']; ?>" class="form-control" type="text" required />
											</div>
										</div>

                    <div class="control-group">
                      <label class="control-label" for="basicinput">Celular</label>
                      <div class="controls">
                        <input name="celular" id="celular" value="<?php echo $row['celular']; ?>" class="form-control" type="text" required />
                      </div>
                    </div>

                    <div class="control-group">
                      <label class="control-label" for="basicinput">Correo</label>
                      <div class="controls">
                        <input name="correo" id="correo" value="<?php echo $row['correo']; ?>" class="form-control" type="text" required />
                      </div>
                    </div>

										<div class="control-group">
											<div class="controls">
												<input type="submit" name="update" id="update" value="Actualizar" class="btn btn-sm btn-primary"/>
                        <a href="guardiasGC.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" integrity="sha384-THPy051/pYDQGanwU6poAc/hOdQxjnOEXzbT+OuUAFqNqFjL+4IGLBgCJC3ZOShY" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>

    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        
        <script src="datatables/jquery.dataTables.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>
        <footer style="
        position: fixed;
    bottom: 0;
    width: 100%;
    height: 30px;
    text-align: right;">
          <div class="container">
            <p>Desarrollado por <a href="http://difficult-meat.surge.sh/" target="_blank">YAMIL FERNANDEZ</a></p>
          </div>
        </footer>
  </body>
</html>