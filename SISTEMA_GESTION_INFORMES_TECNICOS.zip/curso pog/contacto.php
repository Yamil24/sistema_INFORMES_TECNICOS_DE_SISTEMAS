<?php
 
if($_POST) {
    $name = "";
    $ape = "";
    $email = "";
    $message = "";
     
    if(isset($_POST['name'])) {
      $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    }
    if(isset($_POST['ape'])) {
      $ape = filter_var($_POST['ape'], FILTER_SANITIZE_STRING);
    } 
    if(isset($_POST['email'])) {
        $email = str_replace(array("\r", "\n", "%0a", "%0d"), '', $_POST['email']);
        $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    }
     
    if(isset($_POST['message'])) {
        $message = htmlspecialchars($_POST['message']);
    }

    $receptor = "its.peru2020@gmail.com";
    $asunto = "Contacto de servico!! Cliente: ";
    $mensaje = "Detalles del formulario de contacto:\n\n";
    $mensaje .= "Cliente: " . $name . " " . $ape . "\n";
    $mensaje .= "Correo: " . $email . "\n";
    $mensaje .= "Telefono: " . $_POST['telefono'] . "\n";
    $mensaje .= "Mensaje: " . $message . "\n\n";
     
    $headers = 'From: ' . $email . " \r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . " \r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= "Content-type: text/plain; charset=utf-8";
     
    if(mail($receptor, $asunto, $mensaje, $headers)) {
        echo "<script>alert('Gracias por contactarnos, $name. Recibirá una respuesta dentro de las 24 horas.')</script>";
        echo "<script>setTimeout(\"location.href='index.php'\",1000)</script>";
    } else {
        echo "<script>alert('Lo sentimos, pero el correo electrónico no fue enviado.')</script>";
        echo "<script>setTimeout(\"location.href='index.php'\",1000)</script>";
    }
     
} else {
    echo "<script>alert('Algo salió mal')</script>";
}
 
?>