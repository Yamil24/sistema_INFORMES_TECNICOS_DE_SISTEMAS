<?php


include_once('class.pog_base.php');
class visita extends POG_Base
{
	public $id = '';

	/**
	 * @var VARCHAR(255)
	 */
	public $razonSocial;

	/**
	 * @var DATE
	 */
	public $fecha;
	
	/**
	 * @var TIME
	 */
	public $hora;
	
	/**
	 * @var VARCHAR(100)
	 */
	public $motivo;
	
	/**
	 * @var VARCHAR(100)
	 */
	public $accesorio;

	/**
	 * @var VARCHAR(100)
	 */
	public $marca;

	/**
	 * @var VARCHAR(100)
	 */
	public $codigoEquipo;

	/**
	 * @var VARCHAR(100)
	 */
	public $codigoDesbloqueo;

	/**
	 * @var VARCHAR(300)
	 */
	public $falla;

	/**
	 * @var VARCHAR(100)
	 */
	public $estadoEquipo;
	/**
	 * @var VARCHAR(300)
	 */
	public $descripción;
	/**
	 * @var VARCHAR(300)
	 */
	public $recomendación;
	/**
	 * @var VARCHAR(100)
	 */
	public $name;

	public $pog_attribute_type = array(
		"id" => array('db_attributes' => array("NUMERIC", "INT")),
		"razonSocial" => array('db_attributes' => array("TEXT", "VARCHAR", "255")),
		"fecha" => array('db_attributes' => array("TEXT", "VARCHAR", "255")),
		"hora" => array('db_attributes' => array("TEXT", "VARCHAR", "255")),
		"motivo" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
		"accesorio" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
		"marca" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
		"codigoEquipo" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
		"codigoDesbloqueo" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
		"falla" => array('db_attributes' => array("TEXT", "VARCHAR", "300")),
		"estadoEquipo" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
		"descripción" => array('db_attributes' => array("TEXT", "VARCHAR", "300")),
		"recomendación" => array('db_attributes' => array("TEXT", "VARCHAR", "300")),
		"name" => array('db_attributes' => array("TEXT", "VARCHAR", "100")),
	);
	public $pog_query;

	public function __get($attribute)
	{
		if (isset($this->{"_".$attribute}))
		{
			return $this->{"_".$attribute};
		}
		else
		{
			return false;
		}
	}
	
	function visita($razonSocial = '', $fecha='', $hora='', $motivo='', $accesorio='', $marca='', $codigoEquipo='', $codigoDesbloqueo='', $falla='', $estadoEquipo='', $descripción='', $recomendación='', $name='')
	{
		$this->razonSocial = $razonSocial;
		$this->fecha = $fecha;
		$this->hora = $hora;
		$this->motivo = $motivo;
		$this->accesorio = $accesorio;
		$this->marca = $marca;
		$this->codigoEquipo = $codigoEquipo;
		$this->codigoDesbloqueo = $codigoDesbloqueo;
		$this->falla = $falla;
		$this->estadoEquipo = $estadoEquipo;
		$this->descripción = $descripción;
		$this->recomendación = $recomendación;
		$this->name = $name;
	}
	
	
	/**
	* Gets object from database
	* @param integer $guardiasId 
	* @return object $guardias
	*/
	function Get($id)
	{
		$connection = Database::Connect();
		$this->pog_query = "select * from visita where id ='".intval($id)."' LIMIT 1";
		$cursor = Database::Reader($this->pog_query, $connection);
		while ($row = Database::Read($cursor))
		{
			$this->id = $row['id'];
			$this->razonSocial = $this->Unescape($row['razonSocial']);
			$this->fecha = $this->Unescape($row['fecha']);
			$this->hora = $this->Unescape($row['hora']);
			$this->motivo = $this->Unescape($row['motivo']);
			$this->accesorio = $this->Unescape($row['accesorio']);
			$this->marca = $this->Unescape($row['marca']);
			$this->codigoEquipo = $this->Unescape($row['codigoEquipo']);
			$this->codigoDesbloqueo = $this->Unescape($row['codigoDesbloqueo']);
			$this->falla = $this->Unescape($ros['falla']);
			$this->estadoEquipo = $this->Unescape($row['estadoEquipo']);
			$this->descripción = $this->Unescape($row['descripción']);
			$this->recomendación = $this->Unescape($row['recomendación']);
			$this->name = $this->Unescape($row['name']);
		}
		return $this;
	}
	
	
	/**
	* Returns a sorted array of objects that match given conditions
	* @param multidimensional array {("field", "comparator", "value"), ("field", "comparator", "value"), ...} 
	* @param string $sortBy 
	* @param boolean $ascending 
	* @param int limit 
	* @return array $guardiasList
	*/
	function GetList($fcv_array = array(), $sortBy='', $ascending=true, $limit='')
	{
		$connection = Database::Connect();
		$sqlLimit = ($limit != '' ? "LIMIT $limit" : '');
		$this->pog_query = "select * from visita ";
		$guardiasList = Array();
		if (sizeof($fcv_array) > 0)
		{
			$this->pog_query .= " where ";
			for ($i=0, $c=sizeof($fcv_array); $i<$c; $i++)
			{
				if (sizeof($fcv_array[$i]) == 1)
				{
					$this->pog_query .= " ".$fcv_array[$i][0]." ";
					continue;
				}
				else
				{
					if ($i > 0 && sizeof($fcv_array[$i-1]) != 1)
					{
						$this->pog_query .= " AND ";
					}
					if (isset($this->pog_attribute_type[$fcv_array[$i][0]]['db_attributes']) && $this->pog_attribute_type[$fcv_array[$i][0]]['db_attributes'][0] != 'NUMERIC' && $this->pog_attribute_type[$fcv_array[$i][0]]['db_attributes'][0] != 'SET')
					{
						if ($GLOBALS['configuration']['db_encoding'] == 1)
						{
							$value = POG_Base::IsColumn($fcv_array[$i][2]) ? "BASE64_DECODE(".$fcv_array[$i][2].")" : "'".$fcv_array[$i][2]."'";
							$this->pog_query .= "BASE64_DECODE(`".$fcv_array[$i][0]."`) ".$fcv_array[$i][1]." ".$value;
						}
						else
						{
							$value =  POG_Base::IsColumn($fcv_array[$i][2]) ? $fcv_array[$i][2] : "'".$this->Escape($fcv_array[$i][2])."'";
							$this->pog_query .= "`".$fcv_array[$i][0]."` ".$fcv_array[$i][1]." ".$value;
						}
					}
					else
					{
						$value = POG_Base::IsColumn($fcv_array[$i][2]) ? $fcv_array[$i][2] : "'".$fcv_array[$i][2]."'";
						$this->pog_query .= "`".$fcv_array[$i][0]."` ".$fcv_array[$i][1]." ".$value;
					}
				}
			}
		}
		if ($sortBy != '')
		{
			if (isset($this->pog_attribute_type[$sortBy]['db_attributes']) && $this->pog_attribute_type[$sortBy]['db_attributes'][0] != 'NUMERIC' && $this->pog_attribute_type[$sortBy]['db_attributes'][0] != 'SET')
			{
				if ($GLOBALS['configuration']['db_encoding'] == 1)
				{
					$sortBy = "BASE64_DECODE($sortBy) ";
				}
				else
				{
					$sortBy = "$sortBy ";
				}
			}
			else
			{
				$sortBy = "$sortBy ";
			}
		}
		else
		{
			$sortBy = "id";
		}
		$this->pog_query .= " order by ".$sortBy." ".($ascending ? "asc" : "desc")." $sqlLimit";
		$thisObjectName = get_class($this);
		$cursor = Database::Reader($this->pog_query, $connection);
		while ($row = Database::Read($cursor))
		{
			$visita = new $thisObjectName();
			$visita->id = $row['id'];
			$visita->razonSocial = $this->Unescape($row['razonSocial']);
			$visita->fecha = $this->Unescape($row['fecha']);
			$visita->hora = $this->Unescape($row['hora']);
			$visita->motivo = $this->Unescape($row['motivo']);
			$visita->accesorio = $this->Unescape($row['accesorio']);
			$visita->marca = $this->Unescape($row['marca']);
			$visita->codigoEquipo = $this->Unescape($row['codigoEquipo']);
			$visita->codigoDesbloqueo = $this->Unescape($row['codigoDesbloqueo']);
			$visita->falla = $this->Unescape($ros['falla']);
			$visita->estadoEquipo = $this->Unescape($row['estadoEquipo']);
			$visita->descripción = $this->Unescape($row['descripción']);
			$visita->recomendación = $this->Unescape($row['recomendación']);
			$visita->name = $this->Unescape($row['name']);
			$visitaList[] = $visita;
		}
		return $visitaList;
	}
	
	
	/**
	* Saves the object to the database
	* @return integer $guardiasId
	*/
	function Save()
	{
		$connection = Database::Connect();
		$rows = 0;
		if ($this->id!=''){
			$this->pog_query = "select id from `visita` where id ='".$this->id."' LIMIT 1";
			$rows = Database::Query($this->pog_query, $connection);
		}
		if ($rows > 0)
		{
			$this->pog_query = "update `visita` set 
			`razonSocial`='".$this->Escape($this->razonSocial)."', 
			`fecha`='".$this->Escape($this->fecha)."',
			`hora`='".$this->Escape($this->hora)."', 
			`motivo`='".$this->Escape($this->motivo)."',
			`accesorio`='".$this->Escape($this->accesorio)."',
			`marca`='".$this->Escape($this->marca)."',
			`codigoEquipo`='".$this->Escape($this->codigoEquipo)."',
			`codigoDesbloqueo`='".$this->Escape($this->codigoDesbloqueo)."',
			`falla`='".$this->Escape($this->falla)."',
			`estadoEquipo`='".$this->Escape($this->estadoEquipo)."',
			`descripción`='".$this->Escape($this->descripción)."',
			`recomendación`='".$this->Escape($this->recomendación)."',
			`name`='".$this->Escape($this->name)."' where id ='".$this->id."'";
		}
		else
		{
			$this->pog_query = "insert into `visita` (`razonSocial`, `fecha`, `hora`, `motivo`, `accesorio`, `marca`, `codigoEquipo`, `codigoDesbloqueo`, `falla`, `estadoEquipo`, `descripción`, `recomendación`, `name`) values (
			'".$this->Escape($this->razonSocial)."',
			'".$this->Escape($this->fecha)."', 
			'".$this->Escape($this->hora)."',
			'".$this->Escape($this->motivo)."',
			'".$this->Escape($this->accesorio)."',
			'".$this->Escape($this->marca)."',
			'".$this->Escape($this->codigoEquipo)."',
			'".$this->Escape($this->codigoDesbloqueo)."',
			'".$this->Escape($this->falla)."',
			'".$this->Escape($this->estadoEquipo)."',
			'".$this->Escape($this->descripción)."',
			'".$this->Escape($this->recomendación)."', 
			'".$this->Escape($this->name)."')";
		}
		$insertId = Database::InsertOrUpdate($this->pog_query, $connection);
		if ($this->id == "")
		{
			$this->id = $insertId;
		}
		return $this->id;
	}
	
	
	/**
	* Clones the object and saves it to the database
	* @return integer $guardiasId
	*/
	function SaveNew()
	{
		$this->id = '';
		return $this->Save();
	}
	
	
	/**
	* Deletes the object from the database
	* @return boolean
	*/
	function Delete()
	{
		$connection = Database::Connect();
		$this->pog_query = "delete from `visita` where `id`='".$this->id."'";
		return Database::NonQuery($this->pog_query, $connection);
	}
	
	
	/**
	* Deletes a list of objects that match given conditions
	* @param multidimensional array {("field", "comparator", "value"), ("field", "comparator", "value"), ...} 
	* @param bool $deep 
	* @return 
	*/
	function DeleteList($fcv_array)
	{
		if (sizeof($fcv_array) > 0)
		{
			$connection = Database::Connect();
			$pog_query = "delete from `visita` where ";
			for ($i=0, $c=sizeof($fcv_array); $i<$c; $i++)
			{
				if (sizeof($fcv_array[$i]) == 1)
				{
					$pog_query .= " ".$fcv_array[$i][0]." ";
					continue;
				}
				else
				{
					if ($i > 0 && sizeof($fcv_array[$i-1]) !== 1)
					{
						$pog_query .= " AND ";
					}
					if (isset($this->pog_attribute_type[$fcv_array[$i][0]]['db_attributes']) && $this->pog_attribute_type[$fcv_array[$i][0]]['db_attributes'][0] != 'NUMERIC' && $this->pog_attribute_type[$fcv_array[$i][0]]['db_attributes'][0] != 'SET')
					{
						$pog_query .= "`".$fcv_array[$i][0]."` ".$fcv_array[$i][1]." '".$this->Escape($fcv_array[$i][2])."'";
					}
					else
					{
						$pog_query .= "`".$fcv_array[$i][0]."` ".$fcv_array[$i][1]." '".$fcv_array[$i][2]."'";
					}
				}
			}
			return Database::NonQuery($pog_query, $connection);
		}
	}
}
?>