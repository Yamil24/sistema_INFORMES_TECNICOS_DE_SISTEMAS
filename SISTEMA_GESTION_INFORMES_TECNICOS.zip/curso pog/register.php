<?php
session_start();

if(isset($_SESSION['usr_id'])) {
	header("Location: index.php");
}

include_once 'dbconnect.php';

//Establece el error de validación como flag
$error = false;

//check if form is submitted
if (isset($_POST['signup'])) {
	$name = mysqli_real_escape_string($con, $_POST['name']);
	$celular = mysqli_real_escape_string($con, $_POST['celular']);
	$dni = mysqli_real_escape_string($con, $_POST['dni']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

	
	//Nombre sólo puede contener caracteres alfabéticos y espacio (esto varia sgun requerimiento)
	if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
		$error = true;
		$name_error = "El nombre debe contener solo caracteres del alfabeto y espacio.";
	}
	if(!preg_match("/^[0-9]/",$celular) OR (strlen($celular) < 9) OR (strlen($celular) > 9)) {
		$error = true;
		$celular_error = "Ingresa un número movil válido.";
	}
	if(!preg_match("/^[0-9]/",$dni) OR (strlen($dni) < 8) OR (strlen($dni) > 8)) {
		$error = true;
		$dni_error = "Ingresa un númeo de DNI válido.";
	}
	if(strlen($password) < 6) {
		$error = true;
		$password_error = "La contraseña debe tener un mínimo de 6 caracteres.";
	}
	if($password != $cpassword) {
		$error = true;
		$cpassword_error = "Las contraseñas no coinciden";
	}
	if (!$error) {
		if(mysqli_query($con, "INSERT INTO users(name,telefono,dni,password,estado) VALUES('" . $name . "', '" . $celular . "','" . $dni . "', '" . md5($password) . "', '1')")) {
			//$successmsg = "¡Registrado exitosamente! <a href='login.php'>Click here to Login</a>";
			$successmsg = '
			  <div class="alert alert-success alert-dismissable fade in">
			    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			    <strong>EXITO.!</strong> ¡Registrado exitosamente!
			  </div>
			  ';
		} else {
			//$errormsg = "Error de registro. Vuelve a intentarlo más tarde.";
			$errormsg = '
			<div class="alert alert-danger alert-dismissable fade in">
			    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			    <strong>Error de registro.!</strong> Verifica tus datos.
			</div>
			';
		}
	}
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Registro Usuario</title>
		<meta content="width=device-width, initial-scale=1.0" name="viewport" >
		<!--link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" /-->
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<!-- Optional theme -->
		<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	</head>
	<body style="margin-bottom: 30px;">

		<nav class="navbar navbar-default" role="navigation">
			<div class="container-fluid">
				<!-- add header -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<h1 class="pull-xs-left"> | IT - SUPPORTECH | </h1>
				</div>
				<!-- menu items -->
				<div class="collapse navbar-collapse" id="navbar1">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="login.php">Iniciar Sesion</a></li>
						<li class="active"><a href="register.php">Registro</a></li>
					</ul>
				</div>
			</div>
		</nav>

		<div class="container">
			<div class="row">
				<div class="col-md-4 col-md-offset-4 well">
					<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
						<fieldset>
							<legend>Registro</legend>

							<div class="form-group">
								<label for="name">Nombre y Apellido</label>
								<input type="text" name="name" placeholder="Nombres y Apellidos" required value="<?php if($error) echo $name; ?>" class="form-control" />
								<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
							</div>
							
							<div class="form-group">
								<label for="name">Celular</label>
								<input type="text" name="celular" placeholder="Ingrese numero movil" required value="<?php if($error) echo $celular; ?>" class="form-control" />
								<span class="text-danger"><?php if (isset($celular_error)) echo $celular_error; ?></span>
							</div>

							<div class="form-group">
								<label for="name">DNI(Usuario)</label>
								<input type="text" name="dni" placeholder="Ingrese su DNI como usuario" required value="<?php if($error) echo $dni; ?>" class="form-control" />
								<span class="text-danger"><?php if (isset($dni_error)) echo $dni_error; ?></span>
							</div>

							<div class="form-group">
								<label for="name">Contraseña</label>
								<input type="password" name="password" placeholder="Contraseña" required class="form-control" />
								<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
							</div>

							<div class="form-group">
								<label for="name">Repita Contraseña</label>
								<input type="password" name="cpassword" placeholder="Confirmar Contraseña" required class="form-control" />
								<span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
							</div>

							<div class="form-group">
								<input type="submit" name="signup" value="Registrar" class="btn btn-primary" />
							</div>
						</fieldset>
					</form>
					<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
					<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-md-offset-4 text-center">	
				Ya te registaste? <a href="login.php">Inicia Sesion Aqui</a>
				</div>
			</div>
		</div>
		<script src="js/jquery-1.10.2.js"></script>
		<script src="js/bootstrap.min.js"></script>

		<footer style="position: fixed; bottom: 0; width: 100%; height: 30px; text-align: right;">
			<div class="container">
			<p>Desarrollado por <a href="http://difficult-meat.surge.sh/" target="_blank">YAMIL FERNANDEZ</a></p>
			</div>
		</footer>
	</body>
</html>
