<?php
  session_start();
  include_once 'dbconnect.php';
  include "conn.php";
  if (isset($_SESSION['usr_id'])) {
    } else { 
      header("Location: login.php");
    }

  if(isset($_POST['signup'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $ape = mysqli_real_escape_string($con, $_POST['ape']);
    $telefono = mysqli_real_escape_string($con, $_POST['telefono']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

    
  //Nombre sólo puede contener caracteres alfabéticos y espacio (esto varia sgun requerimiento)
  if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
    $error = true;
    $name_error = "El nombre debe contener solo caracteres del alfabeto y espacio.";
  }
  if(!preg_match("/^[0-9]/",$telefono) OR (strlen($telefono) < 9) OR (strlen($telefono) > 9)) {
    $error = true;
    $telefono_error = "Ingresa un número movil válido.";
  }
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
    $error = true;
    $email_error = "Ingresa un correo electrónico válido.";
  }
  if (!$error) {
      $successmsg = '
        <div class="alert alert-success alert-dismissable fade in">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>EXITO.!</strong> ¡Registrado exitosamente! Nos comunicaremos en las proximas horas.
        </div>
        ';
    } else {
      //$errormsg = "Error de registro. Vuelve a intentarlo más tarde.";
      $errormsg = '
      <div class="alert alert-danger alert-dismissable fade in">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Error de registro.!</strong> Verifica tus datos de contacto.
      </div>
      ';
    }
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap-flex.min.css">
    <script src="https://use.fontawesome.com/5765211a64.js"></script>
    <link rel="stylesheet" href="css/app.css">
<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
    <link rel="stylesheet" href="datatables/dataTables.bootstrap.css"/>
    <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link type="text/css" href="css/contacto.css" rel="stylesheet">
    <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'    rel='stylesheet'>

    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/script.js"></script>
    <title>IT - SUPPORTECH</title>
  </head>
  <body style="margin-bottom: 30px; background-color: #E8F2DD;">
    <!-- Header -->

    <header id="header-container">
      <div class="container">
        <div class="row flex-items-xs-middle flex-items-xs-between">
          <div class="col-xs-6">
            <h1 class="pull-xs-left"> | IT - SUPPORTECH | </h1>
          </div>
          <div class="col-xs-6">
            <button class="navbar-toggler pull-xs-right hidden-sm-up" type="button" data-toggle="collapse" data-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
              &#9776;
            </button>
            <button class="btn btn-danger" style="float: right;"><a href="logout.php" class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Salir</a></button>
            <p class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Usuario: <i class="btn btn-success btn-xs"><b><?php echo $_SESSION['usr_name']; ?></b></i></p>
          </div>
        </div>
      </div>
    </header>
    

    <!-- /Header -->

    <!-- Menu -->

    <div id="menu-container">
      <nav id="navMenu" class="navbar-toggleable-xs navbar navbar-light collapse">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-md-12 col-sm-12">
              <ul class="nav navbar-nav">
                <li class="nav-item text-xs-center active">
                  <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="guardiasGC.php">Clientes</a>
                </li>

                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="solicitar.php">Solicitar Visita</a>
                </li>

                <li class="nav-item hidden-sm-up text-xs-center">
                  <a class="nav-link" href="#">Salir</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </div>
    
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <img src="bootstrap/img/support-08.png" style="width: 100%; float: left;">
          </div>
          <div class="col-md-6">
            <div>
              <form action="contacto.php" method="post" style="width: 100%; float: left;">
                <fieldset>
                  <legend class="text-center header">Contáctenos</legend>
                  <div class="form-group">
                    <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                    <div class="col-md-8">
                        <input id="fname" name="name" type="text" placeholder="Ingrese sus Nombres" class="form-control" pattern=[A-Z\sa-z]{3,20} required>
                        <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span><br>
                    </div><br>
                  </div><br>
                  <div class="form-group">
                      <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                      <div class="col-md-8">
                          <input id="lname" name="ape" type="text" placeholder="Ingrese sus Apellidos" class="form-control" pattern=[A-Z\sa-z]{3,20} required>
                          <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span><br>
                      </div><br>
                  </div><br>
                  <div class="form-group">
                      <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-envelope-o bigicon"></i></span>
                      <div class="col-md-8">
                          <input id="email" name="email" type="text" placeholder="email@example.com" class="form-control" pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{1,5}">
                          <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span><br>
                      </div><br>
                  </div><br>
                  <div class="form-group">
                      <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-phone-square bigicon"></i></span>
                      <div class="col-md-8">
                          <input id="phone" name="telefono" type="text" placeholder="Telefono: 000 000 000" class="form-control" pattern="[0-9]{9}" required>
                          <span class="text-danger"><?php if (isset($telefono_error)) echo $telefono_error; ?></span><br>
                      </div><br>
                  </div><br>
                  <div class="form-group">
                      <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-pencil-square-o bigicon"></i></span>
                      <div class="col-md-8">
                          <textarea class="form-control" id="message" name="message" placeholder="Ingrese su mensaje para nosotros aquí. Nos pondremos en contacto con usted dentro de 2 días hábiles." rows="7" required></textarea><br>
                      </div>
                  </div>
                  <br>
                  <div class="form-group">
                      <div class="col-md-5">
                          <button type="submit" name="signup" class="btn btn-primary btn-lg">ENVIAR</button>
                      </div>
                  </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>    

    <!-- /Menu -->

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" integrity="sha384-THPy051/pYDQGanwU6poAc/hOdQxjnOEXzbT+OuUAFqNqFjL+4IGLBgCJC3ZOShY" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>

    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        
        <script src="datatables/jquery.dataTables.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>
  <footer style=" bottom: 0; width: 100%; height: 30px; text-align: right; background-color: white">
    <div class="container">
      <p>Desarrollado por <a href="http://difficult-meat.surge.sh/" target="_blank">YAMIL FERNANDEZ</a></p>
    </div>
  </footer>
  </body>
</html>