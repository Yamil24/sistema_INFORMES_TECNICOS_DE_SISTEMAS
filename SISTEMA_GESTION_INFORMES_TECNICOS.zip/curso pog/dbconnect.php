<?php
//Conneccion a la base de datos
$con = mysqli_connect("localhost", "root", "", "soporte") or die("Error " . mysqli_error($con));
?>