<?php
//Conneccion a la base de dato
$con = mysqli_connect("localhost", "root", "", "soporte") or die("Error " . mysqli_error($con));
?>