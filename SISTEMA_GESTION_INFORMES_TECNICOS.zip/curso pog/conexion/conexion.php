<?php
ini_set("display_errors", 1);
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"

/* ONELOGIN */
$hostname_conexion = "localhost";
$database_conexion = "soporte";
$username_conexion = "root";
$password_conexion = "";
$conexion = mysqli_connect($hostname_conexion, $username_conexion, $password_conexion, $database_conexion) or die("Error " . mysqli_error($conexion));
?>