-- Base de datos: `SOPORTE ---
CREATE DATABASE SOPORTE;
USE SOPORTE;
-- Estructura de tabla para la tabla `cliente`
CREATE TABLE CLIENTE (
  id int NOT NULL primary key AUTO_INCREMENT,
  ruc varchar(11) NOT NULL,
  razonSocial varchar(255) NOT NULL,
  direccion varchar(255) NOT NULL,
  telefono int(7),
  celular int(9),
  correo varchar(255)
);
---------------------------------------------------------
-- Estructura de tabla para la tabla `visita`
CREATE TABLE visita (
  id int NOT NULL primary key AUTO_INCREMENT,
  razonSocial varchar(255) NOT NULL,
  fecha date NOT NULL,
  hora time NOT NULL,
  motivo varchar(100),
  accesorio varchar(100),
  marca varchar(100),
  codigoEquipo varchar(100),
  codigoDesbloqueo varchar(100),
  falla varchar(300) not null,
  estadoEquipo varchar(100),
  descripción varchar(300) not null,
  recomendación varchar(300),
  `name` varchar(100) NOT NULL
);
---------------------------------------------------------
-- Estructura de tabla para la tabla `users`
CREATE TABLE users (
  id int NOT NULL primary key AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  telefono int(9) NOT NULL,
  dni int(8) NOT NULL,
  `password` varchar(100) NOT NULL,
  estado int(8) DEFAULT NULL
);
--------------------------------------------------------------------------------------------
-- Indices de la tabla `CLIENTE`
ALTER TABLE CLIENTE
  ADD UNIQUE KEY `ruc` (`ruc`),
  ADD UNIQUE KEY `correo` (`correo`);
-- Indices de la tabla `users`
ALTER TABLE users
  ADD UNIQUE KEY `dni` (`dni`);
---------------------------------------------------------------------------------------------
COMMIT;
-----------------------------------------------------------------------------------------
-- Volcado de datos para la tabla `users`
INSERT INTO users (`id`, `name`,`telefono`, `dni`, `password`,`estado`) VALUES
(100,'ERICK FERNANDEZ','941941486', '73024666', md5('abc123'),1);
-----------------------------------------------------------------------------------------------
SELECT * FROM cliente