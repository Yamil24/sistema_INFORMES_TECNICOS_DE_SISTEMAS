<?php
session_start();

if(isset($_SESSION['usr_id'])!="") {
	header("Location: index.php");
}

include_once 'dbconnect.php';

//Comprobar de envío el formulario
if (isset($_POST['login'])) {

	$dni = mysqli_real_escape_string($con, $_POST['dni']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$result = mysqli_query($con, "SELECT * FROM users WHERE dni = '" . $dni. "' and password = '" . md5($password) . "'");

	if ($row = mysqli_fetch_array($result)) {

		if($row['estado']==1){
			$_SESSION['usr_id'] = $row['id'];
			$_SESSION['usr_name'] = $row['name'];
			
			header("Location: index.php");
		}else
		$errormsg = "Esta cuenta esta desactivada";
	} else {
		$errormsg = "Revisa los datos!!!";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Inicio de sesión</title>
	
	<meta content="width=device-width, initial-scale=1.0" name="viewport" >
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">

</head>
<body style="margin-bottom: 30px; background-color: #F9E79F;">

<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<!-- add header -->
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<h1 class="pull-xs-left" style="color: #ECF0F1"> | IT - SUPPORTECH | </h1>
		</div>
		<!-- menu items -->
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<li class="active"><a href="login.php">Iniciar Sesion</a></li>
				<li><a href="register.php">Registro</a></li>
			</ul>
		</div>
	</div>
</nav>

<div class="container">
	<div class="row">
		<img src="bootstrap/img/support-08.png" style="margin-left: 1%; padding: 3px; width: 30%; height: 50%;">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginform">
				<fieldset>
					<legend>Inicio de Sesión</legend>

					<div class="form-group">
						<label for="name">Usuario</label>
						<input type="text" name="dni" placeholder="Ingresar Usuario" required class="form-control" />
					</div>

					<div class="form-group">
						<label for="name">Contraseña</label>
						<input type="password" name="password" placeholder="Ingresar Contraseña" required class="form-control" />
					</div>

					<div class="form-group">
						<input type="submit" name="login" value="Iniciar Sesion" class="btn btn-primary" />
						<input type="reset" value="Limpiar" class="btn btn-default" >
					</div>
				</fieldset>
			</form>
			<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 col-md-offset-4 text-center">	
		No tienes cuenta? <a href="register.php">Regitrate aquí</a>
		</div>
	</div>
</div>


<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>

        <footer style="
        position: fixed;
    bottom: 0;
    width: 100%;
    height: 30px;
    text-align: right;">
          <div class="container">
            <p>Desarrollado por <a href="http://difficult-meat.surge.sh/" target="_blank">YAMIL FERNANDEZ</a></p>
          </div>
        </footer>
</body>
</html>
