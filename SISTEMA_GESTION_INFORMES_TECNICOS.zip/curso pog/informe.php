<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html class="supernova"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/json+oembed" href="https://www.jotform.com/oembed/?format=json&amp;url=https%3A%2F%2Fform.jotform.com%2F200607653982661" title="oEmbed Form">
<link rel="alternate" type="text/xml+oembed" href="https://www.jotform.com/oembed/?format=xml&amp;url=https%3A%2F%2Fform.jotform.com%2F200607653982661" title="oEmbed Form">
<meta property="og:title" content="Servicio Técnico" >
<meta property="og:url" content="https://form.jotform.com/200607653982661" >
<meta property="og:description" content="Please click the link to complete this form.">
<meta name="slack-app-id" content="AHNMASS8M">
<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
<link rel="canonical" href="https://form.jotform.com/200607653982661" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=1" />
<meta name="HandheldFriendly" content="true" />
<title>Servicio Técnico</title>
<link href="https://cdn.jotfor.ms/static/formCss.css?3.3.15805" rel="stylesheet" type="text/css" />
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/nova.css?3.3.15805" />
<link type="text/css" media="print" rel="stylesheet" href="https://cdn.jotfor.ms/css/printForm.css?3.3.15805" />
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/themes/CSS/566a91c2977cdfcd478b4567.css?themeRevisionID=59fb4852cf3bfe589c6c6f21"/>
<style type="text/css">
    .form-label-left{
        width:150px;
    }
    .form-line{
        padding-top:-25px;
        padding-bottom:-25px;
    }
    .form-label-right{
        width:150px;
    }
    body, html{
        margin:0;
        padding:0;
        background:#fff;
    }

    .form-all{
        margin:0px auto;
        padding-top:20px;
        width:690px;
        color:#555 !important;
        font-family:"Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Verdana, sans-serif;
        font-size:13px;
    }
</style>

<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */
/*PREFERENCES STYLE*/
    .form-all {
      font-family: Lucida Grande, sans-serif;
    }
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-family: Lucida Grande, sans-serif;
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-family: Lucida Grande, sans-serif;
    }
    .form-header-group {
      font-family: Lucida Grande, sans-serif;
    }
    .form-label {
      font-family: Lucida Grande, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: inline-block;
    float: left;
    text-align: left;
  
    }
  
    .form-line {
      margin-top: -25px;
      margin-bottom: -25px;
    }
  
    .form-all {
      width: 690px;
    }
  
    .form-label-left,
    .form-label-right,
    .form-label-left.form-label-auto,
    .form-label-right.form-label-auto {
      width: 150px;
    }
  
    .form-all {
      font-size: 13px
    }
    .form-all .qq-upload-button,
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-size: 13px
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-size: 13px
    }
  
    .supernova .form-all, .form-all {
      background-color: #fff;
      border: 1px solid transparent;
    }
  
    .form-all {
      color: #555;
    }
    .form-header-group .form-header {
      color: #555;
    }
    .form-header-group .form-subHeader {
      color: #555;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label {
      color: #555;
    }
    .form-sub-label {
      color: #6f6f6f;
    }
  
    .supernova {
      background-color: undefined;
    }
    .supernova body {
      background: transparent;
    }
  
    .form-textbox,
    .form-textarea,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: undefined;
    }
  
    .supernova {
      background-image: none;
    }
    #stage {
      background-image: none;
    }
  
    .form-all {
      background-image: none;
    }
  
  .ie-8 .form-all:before { display: none; }
  .ie-8 {
    margin-top: auto;
    margin-top: initial;
  }
  
  /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/.form-label.form-label-auto {
        
        display: inline-block;
        float: left;
        text-align: left;
      
     
    /* Injected CSS Code */
</style>

<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/buttons/form-submit-button-simple_blue.css?3.3.15805"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/punycode/1.4.1/punycode.min.js"></script>
<script src="https://cdn.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/static/jotform.forms.js?3.3.15805" type="text/javascript"></script>
<script src="https://js.jotform.com/vendor/postMessage.js?3.3.15805" type="text/javascript"></script>
<script src="https://js.jotform.com/WidgetsServer.js?v=1583114692832" type="text/javascript"></script>
<script type="text/javascript">
   JotForm.setConditions([{"action":[{"id":"action_1534525685427","visibility":"Hide","isError":false,"field":"46"}],"id":"1534525710091","index":"2","link":"Any","priority":"2","terms":[{"id":"term_1534525685427","field":"44","operator":"equals","value":"A presupuestar","isError":false}],"type":"field"},{"action":[{"id":"action_1534525651528","visibility":"Hide","isError":false,"field":"47"}],"id":"1534525680915","index":"3","link":"Any","priority":"3","terms":[{"id":"term_1534525651528","field":"44","operator":"equals","value":"Presupuesto aceptado","isError":false}],"type":"field"}]);
	JotForm.init(function(){

 JotForm.formatDate({date:(new Date()), dateField:$("id_"+29)});
 JotForm.displayLocalTime("hour_29", "min_29", "ampm_29");
if (window.JotForm && JotForm.accessible) $('input_5').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_9').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_11').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_45').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_13').setAttribute('tabindex',0);
      JotForm.description('input_13', 'Agregar un * si el IMEI comienza con &quot;0&quot;');
if (window.JotForm && JotForm.accessible) $('input_38').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_15').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_33').setAttribute('tabindex',0);

 JotForm.calendarMonths = ["January","February","March","April","May","June","July","August","September","October","November","December"];
 JotForm.calendarDays = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
 JotForm.calendarOther = {"today":"Today"};
 var languageOptions = document.querySelectorAll('#langList li'); 
 for(var langIndex = 0; langIndex < languageOptions.length; langIndex++) { 
   languageOptions[langIndex].on('click', function(e) { setTimeout(function(){ JotForm.setCalendar("46", false, {"days":{"monday":true,"tuesday":true,"wednesday":true,"thursday":true,"friday":true,"saturday":true,"sunday":true},"future":true,"past":false,"custom":false,"ranges":false,"start":"","end":""}); }, 0); });
 } 
 JotForm.setCalendar("46", false, {"days":{"monday":true,"tuesday":true,"wednesday":true,"thursday":true,"friday":true,"saturday":true,"sunday":true},"future":true,"past":false,"custom":false,"ranges":false,"start":"","end":""});
	JotForm.newDefaultTheme = false;
      JotForm.alterTexts({"alphabetic":"Este campo solo puede contener letras.","alphanumeric":"Este campo solo puede contener letras y números.","ccInvalidCVC":"El número CVC no es válido.","ccInvalidExpireDate":"La fecha de expiración no es válida","ccInvalidNumber":"El número de su tarjeta de crédito no es válido.","ccMissingDetails":"Por favor rellene los datos de su Tarjeta de Crédito","ccMissingDonation":"Ingresa por favor una cantidad a donar","ccMissingProduct":"Por favor seleccione al menos un producto.","characterLimitError":"Demasiados caracteres. El límite es","confirmClearForm":"¿Seguro que quiere eliminar el formulario?","confirmEmail":"El correo electrónico no coincide","currency":"Este campo sólo puede contener valores de moneda.","cyrillic":"Este campo solo puede contener caracteres cirílicos.","dateInvalid":"Esta fecha no es valida. El formato de fecha es {format}","dateLimited":"Esta fecha no está disponible.","disallowDecimals":"Por favor, introduzca un número entero.","email":"Introduzca una dirección e-mail válida","fillMask":"El valor de este campo debe llenar la mascara","freeEmailError":"No se permiten cuentas de correo gratuitas ","generalError":"Existen errores en el formulario, por favor corríjalos antes de continuar.","generalPageError":"Hay errores en esta página. Por favor, corríjalos antes de continuar.","gradingScoreError":"El puntaje total debería ser sólo \"menos que\" o \"igual que\"","incompleteFields":"Existen campos requeridos incompletos. Por favor complételos.","inputCarretErrorA":"El valor introducido no puede ser menor que el mínimo especificado:","inputCarretErrorB":"La entrada no debe ser mas grande que el valor máximo:","lessThan":"Tu puntuación debería ser menor o igual que","maxDigitsError":"El máximo de dígitos permitido es","multipleFileUploads_emptyError":"El fichero {file} está vacío; por favor, selecciona de nuevo los ficheros sin él.","multipleFileUploads_fileLimitError":"Solo {fileLimit} carga de archivos permitida.","multipleFileUploads_minSizeError":"{file} is demasiado pequeño, el tamaño mínimo de fichero es: {minSizeLimit}.","multipleFileUploads_onLeave":"Se están cargando los ficheros, si cierras ahora, se cancelará dicha carga.","multipleFileUploads_sizeError":"{file} es demasiado grande; el tamaño del archivo no debe superar los {sizeLimit}.","multipleFileUploads_typeError":"El fichero {file} posee una extensión no permitida. Sólo están permitidas las extensiones {extensions}.","nextButtonText":"Siguiente","numeric":"Este campo sólo admite valores numéricos.","pastDatesDisallowed":"La fecha debe ser futura","pleaseWait":"Por favor, espere ...","prevButtonText":"Anterior","progressMiddleText":"de","required":"Campo requerido.","requireEveryCell":"Se requieren todas las celdas.","requireEveryRow":"Todas las filas son obligatorias.","requireOne":"Al menos un campo requerido.","seeAllText":"See All","submissionLimit":"¡Lo siento! Sólo se permite una entrada. Múltiples envíos están desactivados para este formulario.","submitButtonText":"Enviar","uploadExtensions":"Solo puede subir los siguientes archivos:","uploadFilesize":"Tamaño del archivo no puede ser mayor que:","uploadFilesizemin":"Tamañao de archivo no puede ser menos de:","url":"Este campo solo contiene una URL válida.","wordLimitError":"Demasiadas palabras. El límite es","wordMinLimitError":"Muy pocas palabras. El mínimo es"});
	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";
    /*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,null,null,null,{"name":"correoElectronico","qid":"4","text":"Correo Electronico","type":"control_email"},{"name":"nombreY","qid":"5","text":"Nombre y Apellido ","type":"control_textbox"},null,null,null,{"name":"contacto","qid":"9","text":"Contacto","type":"control_textbox"},null,{"name":"marca11","qid":"11","text":"Marca \u002F Modelo","type":"control_textbox"},null,{"description":"Agregar un * si el IMEI comienza con &quot;0&quot;","name":"codigoEquipo","qid":"13","text":"Codigo equipo","type":"control_textbox"},null,{"name":"fallaSegun15","qid":"15","text":"Falla segun el Cliente ","type":"control_textarea"},null,null,null,{"name":"motivo","qid":"19","text":"Motivo","type":"control_dropdown"},null,null,null,null,null,null,null,{"name":"enviar","qid":"27","text":"Enviar","type":"control_button"},null,{"name":"ingresoDe","qid":"29","text":"Ingreso de orden","type":"control_datetime"},null,null,null,{"name":"recibidoPor","qid":"33","subLabel":"Atendido y Asesorado por","text":"Recibido por","type":"control_textbox"},null,null,null,null,{"name":"codigoDesbloqueo","qid":"38","text":"Codigo Desbloqueo","type":"control_textbox"},null,null,null,{"name":"estadoDel","qid":"42","text":"Estado del Equipo","type":"control_dropdown"},null,null,{"name":"accesorios","qid":"45","text":"Accesorios","type":"control_textbox"},{"name":"reparacionPrometida","qid":"46","text":"Reparacion prometida para","type":"control_datetime"},null,{"name":"divider","qid":"48","type":"control_divider"},null,null,null,{"name":"ordenCliente","qid":"52","text":"Orden Cliente","type":"control_autoincrement"},{"name":"typeA","qid":"53","type":"control_widget"},{"name":"tags","qid":"54","text":"Tags","type":"control_checkbox"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,null,null,null,{"name":"correoElectronico","qid":"4","text":"Correo Electronico","type":"control_email"},{"name":"nombreY","qid":"5","text":"Nombre y Apellido ","type":"control_textbox"},null,null,null,{"name":"contacto","qid":"9","text":"Contacto","type":"control_textbox"},null,{"name":"marca11","qid":"11","text":"Marca \u002F Modelo","type":"control_textbox"},null,{"description":"Agregar un * si el IMEI comienza con &quot;0&quot;","name":"codigoEquipo","qid":"13","text":"Codigo equipo","type":"control_textbox"},null,{"name":"fallaSegun15","qid":"15","text":"Falla segun el Cliente ","type":"control_textarea"},null,null,null,{"name":"motivo","qid":"19","text":"Motivo","type":"control_dropdown"},null,null,null,null,null,null,null,{"name":"enviar","qid":"27","text":"Enviar","type":"control_button"},null,{"name":"ingresoDe","qid":"29","text":"Ingreso de orden","type":"control_datetime"},null,null,null,{"name":"recibidoPor","qid":"33","subLabel":"Atendido y Asesorado por","text":"Recibido por","type":"control_textbox"},null,null,null,null,{"name":"codigoDesbloqueo","qid":"38","text":"Codigo Desbloqueo","type":"control_textbox"},null,null,null,{"name":"estadoDel","qid":"42","text":"Estado del Equipo","type":"control_dropdown"},null,null,{"name":"accesorios","qid":"45","text":"Accesorios","type":"control_textbox"},{"name":"reparacionPrometida","qid":"46","text":"Reparacion prometida para","type":"control_datetime"},null,{"name":"divider","qid":"48","type":"control_divider"},null,null,null,{"name":"ordenCliente","qid":"52","text":"Orden Cliente","type":"control_autoincrement"},{"name":"typeA","qid":"53","type":"control_widget"},{"name":"tags","qid":"54","text":"Tags","type":"control_checkbox"}]);}, 20); 
</script>
</head>
<body>
<form class="jotform-form" action="informeP.php" method="post" name="form_200607653982661" id="200607653982661" accept-charset="utf-8">
  <input type="hidden" name="formID" value="200607653982661" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <ul class="form-section page-section">
      <li class="form-line" data-type="control_widget" id="id_53">
        <div id="cid_53" class="form-input-wide">
          <div data-widget-name="Submissions Counter" style="width:100%;text-align:Left" data-component="widget-field">
            <iframe title="Submissions Counter" frameBorder="0" scrolling="no" allowtransparency="true" allow="geolocation; microphone; camera; autoplay; encrypted-media; fullscreen" data-type="iframe" class="custom-field-frame" id="customFieldFrame_53" src="" style="border:none;width:600px;height:50px" data-width="600" data-height="50">
            </iframe>
            <div class="widget-inputs-wrapper">
              <input type="hidden" id="input_53" class="form-hidden form-widget  " name="q53_typeA" value="" />
              <input type="hidden" id="widget_settings_53" class="form-hidden form-widget-settings" value="%5B%7B%22name%22%3A%22textBefore%22%2C%22value%22%3A%22N%C2%B0%20Orden%22%7D%2C%7B%22name%22%3A%22hideWidget%22%2C%22value%22%3A%22No%22%7D%5D" data-version="2" />
            </div>
            <script type="text/javascript">
            setTimeout(function()
{
  var _cFieldFrame = document.getElementById("customFieldFrame_53");
  if (_cFieldFrame)
  {
    _cFieldFrame.onload = function()
    {
      if (typeof widgetFrameLoaded !== 'undefined')
      {
        widgetFrameLoaded(53, {
          "formID": 200607653982661
        })
      }
    };
    _cFieldFrame.src = "//widgets.jotform.io/submissionsCounter/?qid=53&ref=" + encodeURIComponent(window.location.protocol + "//" + window.location.host);
    _cFieldFrame.addClassName("custom-field-frame-rendered");
  }
}, 0);
            </script>
          </div>
        </div>
      </li>
      <li class="form-line allowTime" data-type="control_datetime" id="id_29">
        <label class="form-label form-label-left form-label-auto" id="label_29" for="lite_mode_29"> Ingreso de orden </label>
        <div id="cid_29" class="form-input">
          <div data-wrapper-react="true" class="extended">
            <div style="display:none">
              <span class="form-sub-label-container " style="vertical-align:top">
                <input type="tel" readonly="" class="currentDate form-textbox validate[limitDate]" id="day_29" name="q29_ingresoDe[day]" size="2" data-maxlength="2" value="01" autoComplete="off" aria-labelledby="label_29 sublabel_29_day" />
                <span class="date-separate" aria-hidden="true">
                   /
                </span>
                <label class="form-sub-label" for="day_29" id="sublabel_29_day" style="min-height:13px" aria-hidden="false"> Día </label>
              </span>
              <span class="form-sub-label-container " style="vertical-align:top">
                <input type="tel" readonly="" class="form-textbox validate[limitDate]" id="month_29" name="q29_ingresoDe[month]" size="2" data-maxlength="2" value="03" autoComplete="off" aria-labelledby="label_29 sublabel_29_month" />
                <span class="date-separate" aria-hidden="true">
                   /
                </span>
                <label class="form-sub-label" for="month_29" id="sublabel_29_month" style="min-height:13px" aria-hidden="false"> Mes </label>
              </span>
              <span class="form-sub-label-container " style="vertical-align:top">
                <input type="tel" readonly="" class="form-textbox validate[limitDate]" id="year_29" name="q29_ingresoDe[year]" size="4" data-maxlength="4" value="2020" autoComplete="off" aria-labelledby="label_29 sublabel_29_year" />
                <label class="form-sub-label" for="year_29" id="sublabel_29_year" style="min-height:13px" aria-hidden="false"> Año </label>
              </span>
            </div>
            <span class="form-sub-label-container " style="vertical-align:top">
              <input type="text" class="form-textbox validate[limitDate, validateLiteDate]" name="fecha" id="lite_mode_29" size="12" data-maxlength="12" data-age="" value="01/03/2020" readonly="" data-format="ddmmyyyy" data-seperator="/" placeholder="dd/mm/yyyy" autoComplete="off" aria-labelledby="label_29 sublabel_29_litemode" />
              <label class="form-sub-label" for="lite_mode_29" id="sublabel_29_litemode" style="min-height:13px" aria-hidden="false"> Fecha que ingresa el equipo </label>
            </span>
            <span style="white-space:nowrap;display:inline-block" class="allowTime-container">
              <span class="form-sub-label-container " style="vertical-align:top">
                <div id="at_29">
                  at
                </div>
              </span>
              <span class="form-sub-label-container " style="vertical-align:top">
                <select class="currentTime time-dropdown form-dropdown validate[limitDate]" id="hour_29" name="q29_ingresoDe[hour]" disabled="" aria-labelledby="label_29 sublabel_29_hour">
                  <option>  </option>
                  <option value="00"> 00 </option>
                  <option value="01"> 01 </option>
                  <option value="02"> 02 </option>
                  <option value="03"> 03 </option>
                  <option value="04"> 04 </option>
                  <option value="05"> 05 </option>
                  <option value="06"> 06 </option>
                  <option value="07"> 07 </option>
                  <option value="08"> 08 </option>
                  <option value="09"> 09 </option>
                  <option value="10"> 10 </option>
                  <option value="11"> 11 </option>
                  <option value="12"> 12 </option>
                  <option value="13"> 13 </option>
                  <option value="14"> 14 </option>
                  <option value="15"> 15 </option>
                  <option value="16"> 16 </option>
                  <option value="17"> 17 </option>
                  <option value="18"> 18 </option>
                  <option value="19"> 19 </option>
                  <option value="20"> 20 </option>
                  <option selected="" value="21"> 21 </option>
                  <option value="22"> 22 </option>
                  <option value="23"> 23 </option>
                </select>
                <span class="date-separate" aria-hidden="true">
                   :
                </span>
                <label class="form-sub-label" for="hour_29" id="sublabel_29_hour" style="min-height:13px" aria-hidden="false"> Hora </label>
              </span>
              <span class="form-sub-label-container " style="vertical-align:top">
                <select class="time-dropdown form-dropdown validate[limitDate]" id="min_29" name="q29_ingresoDe[min]" disabled="" aria-labelledby="label_29 sublabel_29_minutes">
                  <option>  </option>
                  <option selected="" value="00"> 00 </option>
                  <option value="10"> 10 </option>
                  <option value="20"> 20 </option>
                  <option value="30"> 30 </option>
                  <option value="40"> 40 </option>
                  <option value="50"> 50 </option>
                </select>
                <label class="form-sub-label" for="min_29" id="sublabel_29_minutes" style="min-height:13px" aria-hidden="false"> Minutos </label>
              </span>
            </span>
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_divider" id="id_48">
        <div id="cid_48" class="form-input-wide">
          <div data-component="divider" style="border-bottom:1px solid #e6e6e6;height:1px;margin-left:0px;margin-right:0px;margin-top:5px;margin-bottom:5px">
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_textbox" id="id_5">
        <label class="form-label form-label-left form-label-auto" id="label_5" for="input_5"> Empresa: </label>
        <div id="cid_5" class="form-input">
          <input type="text" id="input_5" name="razonSocial" data-type="input-textbox" class="form-textbox" size="20" value="" data-component="textbox" aria-labelledby="label_5" />
        </div>
      </li>
      <li class="form-line" data-type="control_dropdown" id="id_19">
        <label class="form-label form-label-left form-label-auto" id="label_19" for="input_19"> Motivo </label>
        <div id="cid_19" class="form-input">
          <select class="form-dropdown" id="input_19" name="motivo" style="width:150px" data-component="dropdown" aria-labelledby="label_19">
            <option value="">  </option>
            <option value="Reparación Hardware"> Reparación Hardware </option>
            <option value="Reparación Software"> Reparación Software </option>
            <option value="Soft"> Software </option>
          </select>
        </div>
      </li>
      <li class="form-line" data-type="control_textbox" id="id_11">
        <label class="form-label form-label-left form-label-auto" id="label_11" for="input_11"> Marca / Modelo </label>
        <div id="cid_11" class="form-input">
          <input type="text" id="input_11" name="marca" data-type="input-textbox" class="form-textbox" size="20" value="" data-component="textbox" aria-labelledby="label_11" />
        </div>
      </li>
      <li class="form-line" data-type="control_textbox" id="id_45">
        <label class="form-label form-label-left form-label-auto" id="label_45" for="input_45"> Accesorios </label>
        <div id="cid_45" class="form-input">
          <input type="text" id="input_45" name="accesorio" data-type="input-textbox" class="form-textbox" size="20" value="" data-component="textbox" aria-labelledby="label_45" />
        </div>
      </li>
      <li class="form-line" data-type="control_textbox" id="id_13">
        <label class="form-label form-label-left form-label-auto" id="label_13" for="input_13"> Código equipo </label>
        <div id="cid_13" class="form-input">
          <input type="text" id="input_13" name="codigoEquipo" data-type="input-textbox" class="form-textbox" size="20" value="" data-component="textbox" aria-labelledby="label_13" />
        </div>
      </li>
      <li class="form-line" data-type="control_textbox" id="id_38">
        <label class="form-label form-label-left form-label-auto" id="label_38" for="input_38"> Código Desbloqueo </label>
        <div id="cid_38" class="form-input">
          <input type="text" id="input_38" name="codigoDesbloqueo" data-type="input-textbox" class="form-textbox" size="20" value="" data-component="textbox" aria-labelledby="label_38" />
        </div>
      </li>
      <li class="form-line" data-type="control_textarea" id="id_15">
        <label class="form-label form-label-left form-label-auto" id="label_15" for="input_15"> Falla según el Cliente </label>
        <div id="cid_15" class="form-input">
          <textarea id="input_15" class="form-textarea" name="falla" cols="46" rows="8" data-component="textarea" aria-labelledby="label_15"></textarea>
        </div>
      </li>
      <li class="form-line" data-type="control_dropdown" id="id_42">
        <label class="form-label form-label-left form-label-auto" id="label_42" for="input_42"> Estado del Equipo </label>
        <div id="cid_42" class="form-input">
          <select class="form-dropdown" id="input_42" name="estadoEquipo" style="width:150px" data-component="dropdown" aria-labelledby="label_42">
            <option value="">  </option>
            <option value="Regular"> Regular </option>
            <option value="Bueno"> Bueno </option>
            <option value="Rayado"> Rayado </option>
            <option value="Golpeado"> Golpeado </option>
            <option value="Nuevo "> Nuevo </option>
            <option value="">  </option>
          </select>
        </div>
      </li>
      <li class="form-line" data-type="control_textarea" id="id_15">
        <label class="form-label form-label-left form-label-auto" id="label_15" for="input_15"> Eventos y Soluciones </label>
        <div id="cid_15" class="form-input">
          <textarea id="input_15" class="form-textarea" name="descripción" cols="46" rows="8" data-component="textarea" aria-labelledby="label_15"></textarea>
        </div>
      </li>
      <li class="form-line" data-type="control_textarea" id="id_15">
        <label class="form-label form-label-left form-label-auto" id="label_15" for="input_15"> Observaciones a tomar en cuenta: </label>
        <div id="cid_15" class="form-input">
          <textarea id="input_15" class="form-textarea" name="recomendación" cols="46" rows="8" data-component="textarea" aria-labelledby="label_15"></textarea>
        </div>
      </li>
      <li class="form-line" data-type="control_textbox" id="id_33">
        <label class="form-label form-label-left form-label-auto" id="label_33" for="input_33"> Recibido por </label>
        <div id="cid_33" class="form-input">
          <span class="form-sub-label-container " style="vertical-align:top">
            <input type="text" id="input_33" name="name" data-type="input-textbox" class="form-textbox" size="20" value="" data-component="textbox" aria-labelledby="label_33 sublabel_input_33" />
            <label class="form-sub-label" for="input_33" id="sublabel_input_33" style="min-height:13px" aria-hidden="false"> Atendido y Asesorado por </label>
          </span>
        </div>
      </li>
    
      <li class="form-line" data-type="control_button" id="id_27">
        <div id="cid_27" class="form-input-wide">
          <div style="text-align:center" data-align="center" class="form-buttons-wrapper  ">
            <button id="input_27" type="submit" class="form-submit-button form-submit-button-simple_blue" data-component="button" data-content="">
              Enviar
            </button>
            <span>
              <a href="visitas.php" class="form-submit-button form-submit-button-simple_red" data-component="button" data-content="" style="text-decoration: none; background: red; color: white;">Cancelar</a>
            </span>
            <button id="input_print_27" style="margin-left:25px" type="button" class="form-submit-print form-submit-button-simple_blue" data-component="button">
              <img src="https://cdn.jotfor.ms/images/printer.png" style="vertical-align:middle" />
              <span id="span_print_27" class="span_print">
                IMPRIMIR 2 COPIAS (CLIENTE Y ARCHIVO)
              </span>
            </button>
          </div>
        </div>
      </li>
      <li style="display:none">
        Should be Empty:
        <input type="text" name="website" value="" />
      </li>
    </ul>
  </div><br>
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <input type="hidden" id="simple_spc" name="simple_spc" value="200607653982661" />
  <script type="text/javascript">
  document.getElementById("si" + "mple" + "_spc").value = "200607653982661-200607653982661";
  </script>
  <div class="formFooter-heightMask">
  </div>
  <input type="hidden" id="input_52" name="q52_ordenCliente" class="form-hidden" value="967" data-component="autoincrement" />
</form></body>
</html>
<script type="text/javascript">JotForm.ownerView=true;</script>