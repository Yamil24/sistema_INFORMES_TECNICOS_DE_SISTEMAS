<?php
session_start();
include_once 'dbconnect.php';
include "conn.php";
if (isset($_SESSION['usr_id'])) {
  } else { 
    header("Location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap-flex.min.css">
<link rel="shortcut icon" href="bootstrap/img/1492608037-13-setting-configure-repair-support-optimization-google_83381.ico">
    <script src="https://use.fontawesome.com/5765211a64.js"></script>
    <link rel="stylesheet" href="css/app.css">

    <link rel="stylesheet" href="datatables/dataTables.bootstrap.css"/>
    
         
<style type="text/css" media="screen">
    .pagination {
  display: inline-block;
  padding-left: 0;
  margin: 20px 0;
  border-radius: 4px;
}
.pagination > li {
  display: inline;
}
.pagination > li > a,
.pagination > li > span {
  position: relative;
  float: left;
  padding: 8px 12px;
  line-height: 1.42857143;
  text-decoration: none;
  color: #2fa4e7;
  background-color: #ffffff;
  border: 1px solid #dddddd;
  margin-left: -1px;
}
.pagination > li:first-child > a,
.pagination > li:first-child > span {
  margin-left: 0;
  border-bottom-left-radius: 4px;
  border-top-left-radius: 4px;
}
.pagination > li:last-child > a,
.pagination > li:last-child > span {
  border-bottom-right-radius: 4px;
  border-top-right-radius: 4px;
}
.pagination > li > a:hover,
.pagination > li > span:hover,
.pagination > li > a:focus,
.pagination > li > span:focus {
  color: #157ab5;
  background-color: #eeeeee;
  border-color: #dddddd;
}
.pagination > .active > a,
.pagination > .active > span,
.pagination > .active > a:hover,
.pagination > .active > span:hover,
.pagination > .active > a:focus,
.pagination > .active > span:focus {
  z-index: 2;
  color: #999999;
  background-color: #f5f5f5;
  border-color: #dddddd;
  cursor: default;
}
.pagination > .disabled > span,
.pagination > .disabled > span:hover,
.pagination > .disabled > span:focus,
.pagination > .disabled > a,
.pagination > .disabled > a:hover,
.pagination > .disabled > a:focus {
  color: #999999;
  background-color: #ffffff;
  border-color: #dddddd;
  cursor: not-allowed;
}
.pagination-lg > li > a,
.pagination-lg > li > span {
  padding: 14px 16px;
  font-size: 18px;
}
.pagination-lg > li:first-child > a,
.pagination-lg > li:first-child > span {
  border-bottom-left-radius: 6px;
  border-top-left-radius: 6px;
}
.pagination-lg > li:last-child > a,
.pagination-lg > li:last-child > span {
  border-bottom-right-radius: 6px;
  border-top-right-radius: 6px;
}
.pagination-sm > li > a,
.pagination-sm > li > span {
  padding: 5px 10px;
  font-size: 12px;
}
.pagination-sm > li:first-child > a,
.pagination-sm > li:first-child > span {
  border-bottom-left-radius: 3px;
  border-top-left-radius: 3px;
}
.pagination-sm > li:last-child > a,
.pagination-sm > li:last-child > span {
  border-bottom-right-radius: 3px;
  border-top-right-radius: 3px;
}
.pager {
  padding-left: 0;
  margin: 20px 0;
  list-style: none;
  text-align: center;
}
.pager li {
  display: inline;
}
.pager li > a,
.pager li > span {
  display: inline-block;
  padding: 5px 14px;
  background-color: #ffffff;
  border: 1px solid #dddddd;
  border-radius: 15px;
}
.pager li > a:hover,
.pager li > a:focus {
  text-decoration: none;
  background-color: #eeeeee;
}
.pager .next > a,
.pager .next > span {
  float: right;
}
.pager .previous > a,
.pager .previous > span {
  float: left;
}
.pager .disabled > a,
.pager .disabled > a:hover,
.pager .disabled > a:focus,
.pager .disabled > span {
  color: #999999;
  background-color: #ffffff;
  cursor: not-allowed;
}
.label {
  display: inline;
  padding: .2em .6em .3em;
  font-size: 75%;
  font-weight: bold;
  line-height: 1;
  color: #ffffff;
  text-align: center;
  white-space: nowrap;
  vertical-align: baseline;
  border-radius: .25em;
}
.label[href]:hover,
.label[href]:focus {
  color: #ffffff;
  text-decoration: none;
  cursor: pointer;
}
.label:empty {
  display: none;
}
</style>
      <title>IT - SUPPORTECH</title>
      
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        
        <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'    rel='stylesheet'>

        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>

  </head>
  <body>
    <!-- Header -->

    <header id="header-container">
      <div class="container">
        <div class="row flex-items-xs-middle flex-items-xs-between">
          <div class="col-xs-6">
            <h1 class="pull-xs-left"> | IT - SUPPORTECH | </h1>
          </div>
          <div class="col-xs-6">
            <button class="navbar-toggler pull-xs-right hidden-sm-up" type="button" data-toggle="collapse" data-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
              &#9776;
            </button>
            <button class="btn btn-danger" style="float: right;"><a href="logout.php" class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Salir</a></button>
            <p class="hidden-xs-down text-uppercase font-weight-bold pull-sm-right">Usuario: <i class="btn btn-success btn-xs"><b><?php echo $_SESSION['usr_name']; ?></b></i></p>
          </div>
        </div>
      </div>
    </header>
    

    <!-- /Header -->

    <!-- Menu -->

    <div id="menu-container">
      <nav id="navMenu" class="navbar-toggleable-xs navbar navbar-light collapse">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-md-12 col-sm-12">
              <ul class="nav navbar-nav">
                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item text-xs-center active">
                  <a class="nav-link" href="guardiasGC.php">Clientes</a>
                </li>
                
                <li class="nav-item text-xs-center">
                  <a class="nav-link" href="solicitar.php">Solicitar Visita</a>
                </li>
                
                <li class="nav-item hidden-sm-up text-xs-center">
                  <a class="nav-link" href="#">Salir</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>

    </div>

    <!-- /Menu -->
    <div class="table-responsive">
      <div class="span12">
        <div class="content">
          <?php
            if(isset($_GET['action']) == 'delete'){
			      $id_delete = intval($_GET['id']);
				    $query = mysqli_query($conn, "SELECT * FROM visita WHERE ruc_cliente ='$id_delete'");
				    if(mysqli_num_rows($query) == 0){
					   echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> No se encontraron datos.</div>';
				    }else{
					   $delete = mysqli_query($conn, "DELETE FROM visita WHERE ruc_cliente ='$id_delete'");
					     if($delete){
						    echo '<div class="alert alert-primary alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>  Bien hecho, los datos han sido eliminados correctamente.</div>';
					     }else{
						    echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Error, no se pudo eliminar los datos.</div>';
    					 }
    				  }
    			  }
			    ?>
          <div class="container">
            <div class="row">
              <div class="span12">
                <div class="content">
                  <?php
                    if(@$_GET['variableMensaje']==1){
                      echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido registrado correctamente.</div>';
                    }if(@$_GET['variableMensaje']==2){
                      echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
                    }
                  ?> 
                </div>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title"><i class="icon-user"></i>VISITAS</h3> 
						</div>
						<div class="panel-body">
              <div class="pull-right">
								<a href="informe.php" class="btn btn-sm btn-primary">Nueva Visita</a>
                <a href="guardiasGC.php" class="btn btn-sm btn-danger">Cancelar</a>
							</div><br>
							<hr>
              <div  id='Exportar'>
                <table id="lookup" class="table table-bordered table-hover">  
	                <thead bgcolor="#eeeeee" align="center">
                    <tr>
                      <th>---</th>
                      <th>CLIENTE</th>
                      <th>Fecha</th>
                      <th>Hora</th>
                      <th>Motivo</th>
                      <th></th>
                      <th class="text-center"> Acciones </th> 
                    </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" integrity="sha384-THPy051/pYDQGanwU6poAc/hOdQxjnOEXzbT+OuUAFqNqFjL+4IGLBgCJC3ZOShY" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>

    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        
        <script src="datatables/jquery.dataTables.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>
        <script>
        $(document).ready(function() {
                var dataTable = $('#lookup').DataTable( {
                    
                 "language":    {
                    "sProcessing":     "Procesando...",
                    "sLengthMenu":     "Mostrar _MENU_ registros",
                    "sZeroRecords":    "No se encontraron resultados",
                    "sEmptyTable":     "Ningún dato disponible en esta tabla",
                    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                    "sInfoPostFix":    "",
                    "sSearch":         "Buscar:",
                    "sUrl":            "",
                    "sInfoThousands":  ",",
                    "sLoadingRecords": "Cargando...",
                    "oPaginate": {
                        "sFirst":    "Primero",
                        "sLast":     "Último",
                        "sNext":     "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "oAria": {
                        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                    }
                },

                    "processing": true,
                    "serverSide": true,
                    "ajax":{
                        url :"visitasP.php", // json datasource
                        type: "post",  // method  , by default get
                        error: function(){  // error handling
                            $(".lookup-error").html("");
                            $("#lookup").append('<tbody class="employee-grid-error"><tr><th colspan="3">No hay registrado visitas.</th></tr></tbody>');
                            $("#lookup_processing").css("display","none");
                            
                        }
                    }
                } );
            } );
        </script>
            
                <footer style="
        position: fixed;
    bottom: 0;
    width: 100%;
    height: 30px;
    text-align: right;">
          <div class="container">
            <p>Desarrollado por <a href="http://difficult-meat.surge.sh/" target="_blank">YAMIL FERNANDEZ</a></p>
          </div>  
        </footer>
  </body>
</html>